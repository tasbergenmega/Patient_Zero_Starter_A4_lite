public class Strains {

    public static int editDistance(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] d = new int[n + 1][m + 1];
        for (int i = 0; i <= n; i++) d[i][0] = i;
        for (int j = 0; j <= m; j++) d[0][j] = j;
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    d[i][j] = d[i - 1][j - 1];
                } else {
                    int replace = d[i - 1][j - 1];
                    int delete  = d[i - 1][j];
                    int insert  = d[i][j - 1];
                    d[i][j] = 1 + Math.min(replace, Math.min(delete, insert));
                }
            }
        }
        return d[n][m];
    }


    public static int lcsLength(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] l = new int[n + 1][m + 1];
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (a.charAt(i - 1) == b.charAt(j - 1)) {
                    l[i][j] = l[i - 1][j - 1] + 1;
                } else {
                    l[i][j] = Math.max(l[i - 1][j], l[i][j - 1]);
                }
            }
        }
        return l[n][m];
    }
}
