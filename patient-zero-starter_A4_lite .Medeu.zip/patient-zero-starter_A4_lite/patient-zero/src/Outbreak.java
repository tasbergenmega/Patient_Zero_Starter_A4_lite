import java.util.*;

public class Outbreak {

    public static boolean[] cheapestTests(int n, int[][] nb, int[] cost) {
        int[] parent = new int[n];
        Arrays.fill(parent, -1);
        parent[0] = 0;
        int[] order = new int[n];
        order[0] = 0;
        int tail = 1;
        for (int i = 0; i < tail; i++) {
            int v = order[i];
            for (int u : nb[v]) if (parent[u] < 0) {
                parent[u] = v;
                order[tail++] = u;
            }
        }

        long[] take = new long[n];
        long[] skip = new long[n];
        for (int i = n - 1; i >= 0; i--) {
            int v = order[i];
            take[v] += cost[v];
            if (v != 0) {
                int p = parent[v];
                take[p] += Math.min(take[v], skip[v]);
                skip[p] += take[v];
            }
        }

        boolean[] tested = new boolean[n];
        tested[0] = take[0] <= skip[0];
        for (int i = 1; i < n; i++) {
            int v = order[i];
            int p = parent[v];
            if (!tested[p]) tested[v] = true;
            else tested[v] = take[v] <= skip[v];
        }
        return tested;
    }

    public static int longestChain(int n, int[][] nb) {
        int[] parent = new int[n];
        Arrays.fill(parent, -1);
        parent[0] = 0;
        int[] order = new int[n];
        order[0] = 0;
        int tail = 1;
        for (int i = 0; i < tail; i++) {
            int v = order[i];
            for (int u : nb[v]) if (parent[u] < 0) {
                parent[u] = v;
                order[tail++] = u;
            }
        }

        int[] top1 = new int[n];
        int[] top2 = new int[n];
        int best = 0;
        for (int i = n - 1; i >= 0; i--) {
            int v = order[i];
            best = Math.max(best, top1[v] + top2[v]);
            if (v != 0) {
                int p = parent[v];
                int cand = top1[v] + 1;
                if (cand > top1[p]) { top2[p] = top1[p]; top1[p] = cand; }
                else if (cand > top2[p]) { top2[p] = cand; }
            }
        }
        return best;
    }
}