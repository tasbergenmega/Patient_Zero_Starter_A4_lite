import java.util.*;

public class Marker {

    public static int[] prefixFunction(String p) {
        int[] pi = new int[p.length()];
        for (int i = 1; i < p.length(); i++) {
            int j = pi[i - 1];
            while (j > 0 && p.charAt(i) != p.charAt(j)) j = pi[j - 1];
            if (p.charAt(i) == p.charAt(j)) j++;
            pi[i] = j;
        }
        return pi;
    }

    public static int[] findAll(String text, String p) {
        if (p.isEmpty()) return new int[0];
        int[] pi = prefixFunction(p);
        List<Integer> hits = new ArrayList<>();
        int j = 0;
        for (int i = 0; i < text.length(); i++) {
            while (j > 0 && text.charAt(i) != p.charAt(j)) j = pi[j - 1];
            if (text.charAt(i) == p.charAt(j)) j++;
            if (j == p.length()) {
                hits.add(i - p.length() + 1);
                j = pi[j - 1];
            }
        }
        int[] res = new int[hits.size()];
        for (int i = 0; i < res.length; i++) res[i] = hits.get(i);
        return res;
    }

    public static int sharedWords(String a, String b, int k) {
        int n = a.length(), m = b.length();
        if (n < k || m < k) return 0;
        final long MOD = 1_000_000_007L;
        final long BASE = 131L;

        long top = 1;
        for (int i = 1; i < k; i++) top = top * BASE % MOD;

        // hashes of all windows of b, with positions
        Map<Long, List<Integer>> bHashes = new HashMap<>();
        long h = 0;
        for (int i = 0; i < k; i++) h = (h * BASE + b.charAt(i)) % MOD;
        bHashes.computeIfAbsent(h, x -> new ArrayList<>()).add(0);
        for (int i = 1; i + k <= m; i++) {
            h = (h - b.charAt(i - 1) * top % MOD + MOD) % MOD;
            h = (h * BASE + b.charAt(i + k - 1)) % MOD;
            bHashes.computeIfAbsent(h, x -> new ArrayList<>()).add(i);
        }

        int count = 0;
        h = 0;
        for (int i = 0; i < k; i++) h = (h * BASE + a.charAt(i)) % MOD;
        if (hasMatch(a, 0, b, bHashes.get(h), k)) count++;
        for (int i = 1; i + k <= n; i++) {
            h = (h - a.charAt(i - 1) * top % MOD + MOD) % MOD;
            h = (h * BASE + a.charAt(i + k - 1)) % MOD;
            if (hasMatch(a, i, b, bHashes.get(h), k)) count++;
        }
        return count;
    }

    private static boolean hasMatch(String a, int ai, String b, List<Integer> positions, int k) {
        if (positions == null) return false;
        for (int bj : positions) {
            boolean eq = true;
            for (int t = 0; t < k; t++) {
                if (a.charAt(ai + t) != b.charAt(bj + t)) { eq = false; break; }
            }
            if (eq) return true;
        }
        return false;
    }
}